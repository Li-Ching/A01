﻿namespace WebAPItest.Dtos
{
    public class MessagesDto
    {
        public int FurnitureId { get; set; }

        public string? Message1 { get; set; }

    }
}
