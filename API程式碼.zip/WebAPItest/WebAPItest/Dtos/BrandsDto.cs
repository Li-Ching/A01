﻿namespace WebAPItest.Dtos
{
    public class BrandsDto
    {
        public int BrandId { get; set; }
        
        public int BranchId { get; set; }

        public string? BranchName { get; set; }

        public string? Brand1 { get; set; }

        public string? PhoneNumber { get; set; }

        public string? Address { get; set; }


    }
}
