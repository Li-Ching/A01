﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebAPItest.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebAPItest.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BrandsController : ControllerBase
    {
        private readonly A01Context _a01Context;
        public BrandsController(A01Context a01Context)
        {
            _a01Context = a01Context;
        }
        // GET: api/<BrandsController>
        [HttpGet]
        public ActionResult<IEnumerable<Brand>> Get()
        {
            return _a01Context.Brands;
        }

        // GET api/<BrandsController>/5
        [HttpGet("{BrandId}")]
        public ActionResult<Brand> Get(int brandId)
        {
            var result = _a01Context.Brands.Find(brandId);
            if (result == null)
            {
                return NotFound("沒有此使用者");
            }
            return result;
        }

        // POST api/<BrandsController>
        [HttpPost]
        public IActionResult Post([FromBody] Brand value)
        {
            _a01Context.Brands.Add(value);
            _a01Context.SaveChanges();

            return CreatedAtAction(nameof(Get), new { brandId = value.BrandId }, value);
        }

        // PUT api/<BrandsController>/5
        [HttpPut("{BrandId}")]
        public IActionResult Put(int brandId, [FromBody] Brand value)
        {
            if (brandId != value.BrandId)
            {
                return BadRequest();
            }

            _a01Context.Entry(value).State = EntityState.Modified;

            try
            {
                _a01Context.SaveChanges();
            }
            catch (DbUpdateException)
            {
                if (_a01Context.Brands.Any(u => u.BrandId == brandId))
                {
                    return NotFound();
                }
                else
                {
                    return StatusCode(500, "存取發生錯誤");
                }
            }
            return NoContent();
        }

        // DELETE api/<BrandsController>/5
        [HttpDelete("{BrandId}")]
        public IActionResult Delete(int brandId)
        {
            var delete = _a01Context.Brands.Find(brandId);
            if (delete == null)
            {
                return NotFound();
            }
            _a01Context.Brands.Remove(delete);
            _a01Context.SaveChanges();
            return NoContent();
        }
    }
}
