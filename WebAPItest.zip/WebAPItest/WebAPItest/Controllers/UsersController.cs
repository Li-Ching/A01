﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebAPItest.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebAPItest.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly A01Context _a01Context;

        public UsersController(A01Context a01Context) {
            _a01Context = a01Context;
        }

        // GET: api/<UsersController>
        [HttpGet]
        public ActionResult<IEnumerable<User>> Get()
        {
            return _a01Context.Users;
        }

        // GET api/<UsersController>/5
        [HttpGet("{userId}")]
        public ActionResult<User> Get(int userId)
        {
            var result = _a01Context.Users.Find(userId);
            if (result == null)
            {
                return NotFound("沒有此使用者");
            }
            return result;
        }

        // POST api/<UsersController>
        [HttpPost]
        public ActionResult<User> Post([FromBody] User value)
        {
            _a01Context.Users.Add(value);
            _a01Context.SaveChanges();

            return CreatedAtAction(nameof(Get), new { userId = value.UserId }, value);
        }

        // PUT api/<UsersController>/5
        [HttpPut("{UserId}")]
        public IActionResult Put(int userId, [FromBody] User value)
        {
            if (userId != value.UserId)
            {
                return BadRequest();
            }

            _a01Context.Entry(value).State = EntityState.Modified;

            try
            {
                _a01Context.SaveChanges();
            }
            catch (DbUpdateException)
            {
                if( _a01Context.Users.Any(u => u.UserId == userId))
                {
                    return NotFound();
                }
                else
                {
                    return StatusCode(500, "存取發生錯誤");
                }
            }
            return NoContent();
        }

        // DELETE api/<UsersController>/5
        [HttpDelete("{UserId}")]
        public IActionResult Delete(int UserId)
        {
            var delete = _a01Context.Users.Find(UserId);
            if (delete == null)
            {
                return NotFound();
            }
            _a01Context.Users.Remove(delete);
            _a01Context.SaveChanges();
            return NoContent();
        }
    }
}
