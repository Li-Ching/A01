﻿using System;
using System.Collections.Generic;

namespace WebAPItest.Models;

public partial class Furniture
{
    public int FurnitureId { get; set; }

    public string Type { get; set; } = null!;

    public string Color { get; set; } = null!;

    public string Style { get; set; } = null!;

    public int BrandId { get; set; }

    public string Location { get; set; } = null!;

    public virtual Brand Brand { get; set; } = null!;
}
